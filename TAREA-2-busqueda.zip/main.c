#include <stdio.h>
//Datos recopilados: string.h de la funcion strcmp
//Propuesta: strcmp( char *cadena1,  char *cadena2);
//Parámetros: Las dos cadenas a comparar
//Valor : Un número entero

#include <string.h>
#define LONGITUD 100
#define MAX 2

void Solicitar_datos(char arr[][LONGITUD], int max);
int Buscar_datos(char arr[][LONGITUD], char Busqueda[], int max);
void arrojar_result(int result);
int main()
{
    char arreglo_datos[MAX][LONGITUD];
    char Busqueda[LONGITUD];
    int result;
    Solicitar_datos(arreglo_datos,  MAX);


    result = Buscar_datos(arreglo_datos, Busqueda, MAX);

    // comparacion del resultado de la funcion de busqueda
    arrojar_result( result);
}

void Solicitar_datos(char arr[][LONGITUD], int max)
{
    printf("Teclea los datos:\n");
    for(int i = 0; i < max; i++)
    {
        printf("ingresa los datos %d:", i);
        scanf("%s", arr[i]);
    }
}

int Buscar_datos(char arr[][LONGITUD], char Busqueda[], int max)
{

    printf("Teclea los datos:");
    scanf("%s", Busqueda);

    for(int i = 0; i < max; i++)
       // if (arr[i]== Busqueda)

        //Devuelve 0 si las cadenas de texto son iguales (incluyendo mayúsculas y minúsculas);
        if(strcmp(arr[i], Busqueda)==0)
            //si es igual a cero, que retorne la posicion, si no que retorne -1
            return i;
    return -1;
}

void arrojar_result(int result) {
    if (result >= 0){
        printf("\nlugar %d\n", result);
   // printf("Posicion %d\n", result + 1);
}
    else{
        printf("Lugar -1");
    }
}