#include <stdio.h>
#include <ctype.h>
typedef struct fecha{
    int dia;
    char mes[12];
    int anio;

} tipo_fecha;


void pide_fecha(tipo_fecha *fechass);
void Imprime_fecha(tipo_fecha fechass);

int main(){
    tipo_fecha actual;


    pide_fecha(&actual);
    Imprime_fecha(actual);
}

void pide_fecha(tipo_fecha *fechass){
    printf("--Que Dia es?:");
    scanf("%d", &fechass->dia);
//_____________
    printf("-----Que Mes es?:");
    scanf("%s", fechass->mes);

    int bandera = 0; // Fuera
    for (int i = 0; fechass->mes[i] != '\0'; i++) {
        if (fechass->mes[i] == ' ') {
            bandera = 0; // Fuera de palabra
            fechass->mes[i] = tolower(fechass->mes[i]); //MIN
        }
        else if (bandera) {
                // Dentro
                fechass->mes[i] = tolower(fechass->mes[i]); //MIN
            }
        else {
                bandera = 1;
                fechass->mes[i] = toupper(fechass->mes[i]); //Mayuscula
            }
        }
//_____________
    printf("-------Que Año es :");
    scanf("%d", &fechass->anio);

}
void Imprime_fecha(tipo_fecha fechass){
  
    printf("%02d/", fechass.dia);
    printf("%s/", fechass.mes);
    printf("%04d", fechass.anio);
}