#include <stdio.h>
#include <string.h>
#define MAX 40
void PALINDROMOPOSI(char * cadena);
int main() {
  char cadena[MAX];

    printf("Ingrese los digitos \n");
    scanf("%s", &cadena);

  PALINDROMOPOSI (cadena);

}
void PALINDROMOPOSI(char * cadena ) {
    int tamañoDeCadena = strlen(cadena);

    int indiceFin = tamañoDeCadena - 1;

    int indiceInicio = 0;

    if (indiceInicio >= indiceFin ) {
        indiceInicio++;
        indiceFin--;
    }
if (cadena[indiceInicio] == cadena[indiceFin] ){
        printf("1\n");

    }
 }