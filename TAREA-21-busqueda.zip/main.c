#include <stdio.h>


int main() {
    int arreglo[100];
    int tam;
    int x;
    int indice;
    printf("Ingrese la lista de numeros:\n");
    scanf("%i", &tam);
    for (int i = 0; i < tam; i++) {
        printf("Teclea el numero [%i]:\n", i);
        scanf("%i", &arreglo[i]);
    }
    for (int i = 0; i < tam; i++) {
        printf("El numero esta en la posicion [%i]  %i\n", i, arreglo[i]);
    }
    printf("Tclea el valor a buscar:");
    scanf("%i",&x);

    for (int i=0; i<tam; i++){
        if(arreglo[i]==x){
            indice=i;
        }
    }
    for (int i=0; i<tam; i++){
        if(arreglo[tam-1]<=x) {
            if (arreglo[i] <= x) {
                if (arreglo[i] == x) {
                    indice = i;
                }
                else {
                    indice = i + 1;
                }
            }
        }
    }
    if(arreglo[tam-1]>x) {
        for (int i = 0; i < tam; i++) {
            if (arreglo[i] < x) {
                indice = i + 1;
            }
        }
    }
    printf("Su Salida %i", indice);
}