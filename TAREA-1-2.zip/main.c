


#include <stdio.h>

int Fibonacci (int b );
int main() {

    int numeros;
    int resultados;
    printf("ingresa un digito pls \n");
    scanf("%d", &numeros);

    resultados= Fibonacci (numeros);
    printf("%d", resultados);
}
// 0 1 1 2 3 5 8
// 0 1/2 3 4 5 6
int Fibonacci (int numeros) {
    int resultados;

     if ( numeros==0 ){
        resultados= 0;}
    else if (numeros== 1){
        resultados=1;
    }
   else {
      resultados=  Fibonacci(numeros - 1) + Fibonacci(numeros-2);
   }
    return (resultados);
        }